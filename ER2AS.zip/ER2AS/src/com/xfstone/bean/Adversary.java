package com.xfstone.bean;

import com.xfstone.util.StringOperation;

public class Adversary {

    public String[] generateforgery(int BitLength){

        String A = StringOperation.generateRandomBinaryString(BitLength);
        String B = StringOperation.generateRandomBinaryString(BitLength);
        StringBuilder sb = new StringBuilder(BitLength);
        for(int i=0;i<BitLength;i++){
            sb.append('0');
        }
        String C=sb.toString();
        return new String[]{A,B,C};
    }

}
