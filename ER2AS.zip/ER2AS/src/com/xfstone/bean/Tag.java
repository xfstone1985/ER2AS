package com.xfstone.bean;

import com.xfstone.util.StringOperation;

public class Tag {
    private String ID;
    private String keyold;
    private String keynew;
    private String IDSold;
    private String IDSnew;

    private String n1;

    private String n2;

    public String getN1() {
        return n1;
    }

    public void setN1(String n1) {
        this.n1 = n1;
    }

    public String getN2() {
        return n2;
    }

    public void setN2(String n2) {
        this.n2 = n2;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getKeyold() {
        return keyold;
    }

    public void setKeyold(String keyold) {
        this.keyold = keyold;
    }

    public String getKeynew() {
        return keynew;
    }

    public void setKeynew(String keynew) {
        this.keynew = keynew;
    }

    public String getIDSold() {
        return IDSold;
    }

    public void setIDSold(String IDSold) {
        this.IDSold = IDSold;
    }

    public String getIDSnew() {
        return IDSnew;
    }

    public void setIDSnew(String IDSnew) {
        this.IDSnew = IDSnew;
    }

    public boolean checkC(String A, String B, String C) {
        boolean flag = false;
        String n1 = StringOperation.binaryStringXOR(A, StringOperation.getRef(this.getIDSold(), this.getKeyold()));
        String n2 = StringOperation.binaryStringXOR(StringOperation.binaryStringXOR(B, n1), this.getIDSold());
        System.out.print("tag computers n1:");
        System.out.println(n1);
        System.out.print("tag computers n2:");
        System.out.println(n2);
        String C1 = StringOperation.getRef(StringOperation.getRef(n1, n1), StringOperation.getRef(n2, n2));
        System.out.print("tag computers C:");
        System.out.println(C1);
        if (C1.equals(C)) {
            flag = true;
            this.setN1(n1);
            this.setN2(n2);
        }
        return flag;
    }

    public String updateIDS(String n1, String n2) {
        String t1 = StringOperation.binaryStringXOR(this.getIDSold(), n1);
        String t2 = StringOperation.binaryStringXOR(this.getKeyold(), n2);
        String t3 = StringOperation.getRotLeft(t1, t2);
        String t4 = StringOperation.binaryStringXOR(n1, n2);
        String IDS = StringOperation.getRef(t3, t4);
        return IDS;

    }

    public String updateKey(String n1, String n2) {
        String t1 = StringOperation.getRotRight(this.getKeyold(), n1);
        String t2 = StringOperation.binaryStringXOR(this.getIDSold(), n2);
        String keynew = StringOperation.getRef(t1, t2);
        return keynew;
    }

    public String computerD(String n1, String n2) {
        String IDSnew = this.updateIDS(n1, n2);
        String Keynew = this.updateKey(n1, n2);
        String t1 = StringOperation.getRotLeft(IDSnew, Keynew);
        String t2 = StringOperation.binaryStringXOR(n1, n2);
        String t3 = StringOperation.getRef(t1, t2);
        String t4 = StringOperation.getRotRight(t3, n2);
        String D = StringOperation.binaryStringXOR(t4, this.getID());
        this.setIDSnew(IDSnew);
        this.setKeynew(Keynew);
        return D;
    }
}
