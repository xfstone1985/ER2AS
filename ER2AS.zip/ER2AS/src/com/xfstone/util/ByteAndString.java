package com.xfstone.util;

import java.nio.ByteBuffer;

public class ByteAndString {

    public static byte[] binaryStringConvertoByteArray(String binaryString){
        int intValue=Integer.parseInt(binaryString,2);
        ByteBuffer buffer = ByteBuffer.allocate(Integer.BYTES);
        buffer.putInt(intValue);
        return buffer.array();

    }

    public static String byteArraytoBinaryString(byte[] bytes){
        StringBuilder binaryString=new StringBuilder();
        for (byte b:bytes){
            for (int i=7;i>=0;i--){
                binaryString.append((b>>i)&1);
            }
        }
        return binaryString.toString();
    }
}
