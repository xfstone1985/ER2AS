package com.xfstone.util;

import java.util.Random;

public class StringOperation {

    public static String generateRandomBinaryString(int length) {
        Random random = new Random();
        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            sb.append(random.nextInt(2));
        }
        return sb.toString();
    }

    public static String binaryStringXOR(String x, String y) {
        StringBuilder sb = new StringBuilder(x.length());
        for (int i = 0; i < x.length(); i++) {
            if (x.charAt(i) != y.charAt(i)) {
                sb.append("1");
            } else sb.append("0");
        }
        return sb.toString();
    }

    public static int getHammingWeight(String x) {
        int n = 0;
        for (int i = 0; i < x.length(); i++) {
            if (x.charAt(i) == '1') n++;
        }
        return n;
    }

    public static String getRotLeft(String x, String y) {
        int n = getHammingWeight(y);
        String part1 = x.substring(0, n);
        String part2 = x.substring(n);
        return part2 + part1;
    }


    public static String getRotRight(String x, String y) {
        int n = getHammingWeight(y);
        String part1 = x.substring(x.length() - n, x.length());
        String part2 = x.substring(0, x.length() - n);
        return part1 + part2;
    }

    public static String getRef(String x, String y) {
        StringBuilder z = new StringBuilder(x.length());
        for (int i = 0; i < x.length(); i++) {
            if (x.charAt(i) == '1' && y.charAt(i) == '0') {
                z.append(x.charAt((i + 1) % x.length()));
            }
            if (x.charAt(i) == y.charAt(i)) {
                z.append('0');
            }
            if (x.charAt(i) == '0' && y.charAt(i) == '1') {
                z.append(y.charAt((i + 1) % y.length()));
            }
        }
        return z.toString();
    }
}
