package com.xfstone.test;

import com.xfstone.bean.Adversary;
import com.xfstone.bean.ReaderAndServer;
import com.xfstone.bean.Tag;
import com.xfstone.util.StringOperation;
import org.junit.Test;

import static org.junit.Assert.*;

public class AdversaryTest {

    @Test
    public void impersonateattacktest() {
        int BitLength=8;
        Tag tag=new Tag();
        Adversary adversary=new Adversary();
        tag.setIDSold("01010010");
        tag.setKeyold("11000110");
        System.out.println("tag's IDS:"+tag.getIDSold());
        System.out.println("tag's Key:"+tag.getKeyold());
        System.out.println("-----adversary begins to impersonate a reader to communicate with a legitimate tag-----");
        System.out.println("-----step1:adversary sends hello to tag-----");
        System.out.println("-----step2:tag sends its IDS to tag -----");
        System.out.println("-----step3:adversary computers{A',B',C'} and sends it to tag-----");
        String A=adversary.generateforgery(BitLength)[0];
        String B=adversary.generateforgery(BitLength)[1];
        String C=adversary.generateforgery(BitLength)[2];
        System.out.printf("A':%s B':%s C':%s",A,B,C);
        System.out.println();
        System.out.println("-----step4:tag checks the received message{A',B',C'}-----");
        boolean flag=tag.checkC(A,B,C);
        if (flag==true) System.out.println("C=C',so message C is checked, adversary is authenticated by the tag!");
    }

    @Test
    public void desynchronizationattacktest() {
        int BitLength=8;
        Tag tag=new Tag();
        Adversary adversary=new Adversary();
        ReaderAndServer readerAndServer=new ReaderAndServer();
        tag.setID("00000001");
        tag.setIDSold("01000011");
        tag.setKeyold("00001000");
        readerAndServer.setID("00000001");
        readerAndServer.setIDSold("01010010");
        readerAndServer.setKeyold("11000110");
        readerAndServer.setIDSnew("01000011");
        readerAndServer.setKeynew("00001000");
        System.out.println("-----initial status-----");
        System.out.println("tag stores:");
        System.out.printf("{IDS_1,Key_1}={%s,%s}",tag.getIDSold(),tag.getKeyold());
        System.out.println();
        System.out.println("reader stores:");
        System.out.printf("{IDS_1,Key_1}={%s,%s}  ",readerAndServer.getIDSnew(),readerAndServer.getKeynew());

        System.out.printf("{IDS_0,Key_0}={%s,%s}",readerAndServer.getIDSold(),readerAndServer.getKeyold());
        System.out.println("");
        System.out.println("-----adversary begins to impersonate a reader to communicate with a legitimate tag-----");
        System.out.println("-----step1:adversary sends hello to tag-----");
        System.out.println("-----step2:tag sends its IDS to tag -----");
        System.out.println("-----step3:adversary computers{A',B',C'} and sends it to tag-----");
        String A=adversary.generateforgery(BitLength)[0];
        String B=adversary.generateforgery(BitLength)[1];
        String C=adversary.generateforgery(BitLength)[2];
        System.out.printf("A':%s B':%s C':%s",A,B,C);
        System.out.println();
        System.out.println("-----step4:tag checks the received message{A',B',C'}-----");
        boolean flag=tag.checkC(A,B,C);
        if (flag==true) System.out.println("C=C',so message C is checked, adversary is authenticated by the tag!");
        tag.setIDSnew(tag.updateIDS(tag.getN1(), tag.getN2()));
        tag.setKeynew(tag.updateKey(tag.getN1(),tag.getN2()));
        System.out.println("tag's new IDS:"+tag.getIDSnew());
        System.out.println("tag's new Key:"+tag.getKeynew());
        System.out.println("-----adversary aborts the protocol and reader'still stores:-----");
        System.out.printf("{IDS_1,Key_1}={%s,%s}  ",readerAndServer.getIDSnew(),readerAndServer.getKeynew());
        System.out.printf("{IDS_0,Key_0}={%s,%s}",readerAndServer.getIDSold(),readerAndServer.getKeyold());
        System.out.println();
        System.out.println("the information between tag and reader is de-synchronization");
    }
}