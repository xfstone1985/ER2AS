package com.xfstone.test;

import com.xfstone.util.StringOperation;
import org.junit.Test;

public class StringOperationTest {

    @Test
    public void generateRandomBinaryStringTest() {
        StringOperation stringOperation = new StringOperation();
        String n1 = stringOperation.generateRandomBinaryString(8);
        String n2 = stringOperation.generateRandomBinaryString(8);
        System.out.println("n1:" + n1);
        System.out.println("n2:" + n2);
    }

    @Test
    public void binaryStringXORTest() {
        StringOperation stringOperation = new StringOperation();
        String n1 = stringOperation.generateRandomBinaryString(8);
        String n2 = stringOperation.generateRandomBinaryString(8);
        System.out.println("n1:" + n1);
        System.out.println("n2:" + n2);
        System.out.println("n1 xor n2:" + stringOperation.binaryStringXOR(n1, n2));
    }


    @Test
    public void getHammingWeightTest() {
        StringOperation stringOperation = new StringOperation();
        String n1 = stringOperation.generateRandomBinaryString(8);
        System.out.println("n1:" + n1);
        System.out.println("n1's hammingweight is:" + stringOperation.getHammingWeight(n1));
    }

    @Test
    public void getRofTest() {
        StringOperation stringOperation = new StringOperation();
        System.out.println("x: 10010110");
        System.out.println("y: 10010110");
        System.out.println("z: " + stringOperation.getRef("10010110", "10010110"));
    }

    @Test
    public void getRotRightTest() {
        StringOperation stringOperation = new StringOperation();
        String n1 = stringOperation.generateRandomBinaryString(8);
        String n2 = stringOperation.generateRandomBinaryString(8);
        System.out.println(n1);
        System.out.println(n2);
        System.out.println(StringOperation.getRef(n1,n2));
        System.out.println(StringOperation.getRef(n2,n1));
    }

    @Test
    public void getRotLeftTest() {
        StringOperation stringOperation = new StringOperation();
        String n1 = stringOperation.generateRandomBinaryString(8);
        String n2 = stringOperation.generateRandomBinaryString(8);
        System.out.println(n1);
        System.out.println(n2);
        System.out.println(stringOperation.getRotLeft(n1, n2));
    }
}